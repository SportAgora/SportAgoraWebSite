const ingressosModel = require('../models/model-ingressos');
const {MercadoPagoConfig, Preference, Payment} = require('mercadopago');
const { body, validationResult } = require('express-validator');
const {validarCPF} = require("../helpers/validar_pagamento");
const axios = require('axios');

const mp = new MercadoPagoConfig({
  accessToken: process.env.MP_ACCESS_TOKEN,
});

module.exports = {
carregarInscricaoEvento: async (req, res) => {
    try {
    const eventoId = req.query.id;
    const evento = await ingressosModel.buscarPagPorId(eventoId);

    if (evento.usuario_id == req.session.usuario.id) {
        return res.render('pages/erro', {
            error: 403,
            mensagem: "Você não pode se inscrever no seu próprio evento."
        });
    }

    let ingressos = JSON.parse(req.body.ingressosSelecionados);

     ingressos = ingressos.map(i => {
      const [id, tipo] = i.id.split('_');
      return { id, tipo, qtd: i.qtd };
    });

    const ingressosDados = await ingressosModel.buscarIngressos(ingressos);
    res.render('pages/evento-inscricao', { 
        evento, 
        ingressos: ingressosDados, 
        dados: {
            telefone:"",
            cpf:"",
            genero:""
        },
        erros:""
    });

    } catch (e) {
    console.error(e);
    res.redirect('/erro')
    }
    },
    regrasValidacaoPagamento: [
    body("telefone").matches(/^\d{2}\d{9}$/)
    .withMessage("Telefone inválido"),
    body("cpf").custom(cpf => {
            if (!validarCPF(cpf)) {
                throw new Error("CPF inválido");
            }
            return true;
        }),
//     body("nascimento").custom(value => {
//     const hoje = new Date();
//     const dataNasc = new Date(value);
//     let idade = hoje.getFullYear() - dataNasc.getFullYear();
//     const m = hoje.getMonth() - dataNasc.getMonth();
//     if (m < 0 || (m === 0 && hoje.getDate() < dataNasc.getDate())) {
//         idade--;
//     }
//     if (idade < 14) {
//         throw new Error("Você precisa ter mais de 14 anos");
//     }
//     return true; // precisa retornar true se estiver válido
// })
    ],

    pagamentoEvento: async (req, res) => {
    const {telefone, cpf, genero} = req.body;
    let dados = {
        telefone,
        cpf,
        genero
    }
    const evento = JSON.parse(req.body.evento);
    let ingressos = JSON.parse(req.body.ingressos);
        
    const errors = validationResult(req);
    if(!errors.isEmpty()) {
        console.log(errors);
        return res.render('pages/evento-inscricao',{
            dados,
            erros: errors,
            evento,
            ingressos
        })
    }

    try {
            const items = ingressos.map(ingresso => {
            // calcula o valor, dividindo por 2 se for meia
            const valor = ingresso.ingresso_meia === 1
                ? parseFloat(ingresso.ingresso_valor) / 2
                : parseFloat(ingresso.ingresso_valor);

            return {
                title: ingresso.ingresso_nome,
                unit_price: valor,
                quantity: ingresso.qtd
            };
            });

            const preference = new Preference(mp);
            const ingressosPag = await preference.create({
            body: {
                items,
                back_urls: {
                    success: `${process.env.URL_BASE}/ingresso/sucesso`,
                    failure: `${process.env.URL_BASE}/ingresso/erro`,
                    pending: `${process.env.URL_BASE}/ingresso/pending`
                },
                auto_return: "approved", // volta automaticamente ao site quando aprovado
                // NÃO PASSAMOS payer_email → o MP vai pedir na hora do checkout
                },
            });

            // criar a inscrição no evento com pagamento_feito = false
            const inscricoesIds = await ingressosModel.criarInscricaoEvento({
                usuario_id: req.session.usuario.id,
                evento_id: evento.evento_id,
                telefone,
                cpf,
                genero
            }, ingressos);

            req.session.inscricoesCriadas = inscricoesIds;
            req.session.eventoId = evento.evento_id;

        return res.redirect(ingressosPag.init_point)    
    } catch (e) {
    console.error(e);
    res.redirect('/erro')
    }
    },
    sucesso: async (req, res) => {
        const { payment_id } = req.query;

        // Create a Payment instance using the existing mp configuration
        const paymentClient = new Payment(mp);

        // buscar pagamento no Mercado Pago pra confirmar
        const payment = await paymentClient.get({id: payment_id}); // Use the correct method: get

        if(payment.status === 'approved') {
            await ingressosModel.ativarInscricaoPagamento(req.session.inscricoesCriadas);
            let evento = await ingressosModel.buscarPagPorId(req.session.eventoId);

            return res.render('pages/evento-inscrito', {
                evento
            })
        }

        // se não aprovado
        res.redirect('/ingresso/erro');
    },

    erro: (req, res) => {
        res.redirect("/erro");
    },
    carregarIngresso: async (req, res) => {
        const inscricaoId = req.query.id;
        const ingresso = await ingressosModel.buscarInscricaoPorId(inscricaoId);

        if (!ingresso) {
            return res.render('pages/error', {
                error: 404,
                mensagem: "Inscrição não encontrada."
            });
        }
        if (ingresso.usuario_id != req.session.usuario.id) {
            return res.render('pages/error', {
                error: 403,
                mensagem: "Você não pode ver esse ingresso."
            });
        }

        ingresso.evento_endereco_cep = ingresso.evento_endereco_cep.replace(/\D/g, '');
        const { data } = await axios.get(`https://viacep.com.br/ws/${ingresso.evento_endereco_cep}/json/`);
        if(data.erro) return res.render('pages/error', {error:500, mensagem:"Erro ao buscar endereço do evento."});
        ingresso.evento_endereco_completo = data
        res.render('pages/sobre_ingresso', { ingresso });
    },
    carregarValidarIngresso: async (req, res) => {
        id = req.query.id;
        const evento = await ingressosModel.buscarPagPorId(id);
        if (!evento) {
            return res.render('pages/error', {
                error: 404,
                mensagem: "Evento não encontrado."
            });
        }
        if (evento.usuario_id != req.session.usuario.id) {
            return res.render('pages/error', {
                error: 403,
                mensagem: "Você não pode validar ingressos deste evento."
            });
        }
        res.render('pages/validar_ingresso', {evento_id: id});
    },
    validarIngresso: async (req, res) => {
    const { inscricao_id, evento_id } = req.body;
    const ingresso = await ingressosModel.buscarInscricaoPorId(inscricao_id);
    console.log(ingresso)

    if (!ingresso) return res.json({ error: true, message: "Inscrição não encontrada." });
    if (ingresso.evento_id != evento_id) return res.json({ error: true, message: "Essa inscrição não é deste evento." });
    if (ingresso.pagamento_feito == 0) return res.json({ error: true, message: "Essa inscrição não foi paga." });
    if (ingresso.entrada_validada == 1) return res.json({ error: true, message: "Essa inscrição já foi validada." });

    await ingressosModel.validarInscricao(inscricao_id);
    return res.json({ success: true, message: "Ingresso validado com sucesso!" });
    }
}